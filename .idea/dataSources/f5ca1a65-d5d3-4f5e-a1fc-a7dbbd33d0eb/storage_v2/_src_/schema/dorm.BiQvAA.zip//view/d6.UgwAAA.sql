create view d6 as
  select `dorm`.`tb_stu`.`id`         AS `id`,
         `dorm`.`tb_stu`.`stu_name`   AS `stu_name`,
         `dorm`.`tb_stu`.`age`        AS `age`,
         `dorm`.`tb_stu`.`sex`        AS `sex`,
         `dorm`.`tb_stu`.`class_ID`   AS `class_ID`,
         `dorm`.`tb_stu`.`college_ID` AS `college_ID`,
         `dorm`.`tb_stu`.`stu_phone`  AS `stu_phone`,
         `dorm`.`tb_stu`.`address`    AS `address`,
         `dorm`.`tb_stu`.`room_ID`    AS `room_ID`,
         `dorm`.`tb_stu`.`bed`        AS `bed`,
         `dorm`.`tb_stu`.`checkIn`    AS `checkIn`,
         `dorm`.`tb_stu`.`identity`   AS `identity`,
         `dorm`.`tb_stu`.`password`   AS `password`
  from `dorm`.`tb_stu`
  where `dorm`.`tb_stu`.`room_ID` in
        (select `dorm`.`tb_room`.`room_ID` from `dorm`.`tb_room` where (`dorm`.`tb_room`.`dorm_ID` = 6));

